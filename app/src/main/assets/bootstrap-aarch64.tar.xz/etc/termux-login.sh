##
## This script is sourced by /data/data/com.nobiterminal/files/usr/bin/login before executing shell.
##

# NobiTerminal: time-aware greeting, printed by the login script before the shell starts.
_nobi_hour="$(date +%H 2>/dev/null)"
case "$_nobi_hour" in
0[0-9]|1[01]) _nobi_greeting="Good morning" ;;
12|1[3-6]) _nobi_greeting="Good afternoon" ;;
*) _nobi_greeting="Good evening" ;;
esac
printf '\033[1;38;5;141m%s, Sam.\033[0m\n' "$_nobi_greeting"
unset _nobi_hour _nobi_greeting
