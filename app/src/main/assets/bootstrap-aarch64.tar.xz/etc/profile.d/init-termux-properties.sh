if [ ! -f /data/data/com.nobiterminal/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.nobiterminal/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.nobiterminal/files/home/.termux
	cp /data/data/com.nobiterminal/files/usr/share/examples/termux/termux.properties /data/data/com.nobiterminal/files/home/.termux/
fi
